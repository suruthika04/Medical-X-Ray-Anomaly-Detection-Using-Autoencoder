# Model artifacts

Generated files are intentionally excluded from Git.

After `python train.py`:

- `autoencoder.keras`
- `threshold.npy`
- `training_history.png`

After `python evaluate.py`:

- `reconstruction_error_distribution.png`
- `confusion_matrix.png`

Do not upload patient-identifiable medical images or private clinical data to GitHub.
