import tensorflow as tf
from tensorflow.keras import Model, layers

IMG_SIZE = 128
INPUT_SHAPE = (IMG_SIZE, IMG_SIZE, 1)


def build_autoencoder():
    """Build a convolutional encoder-decoder for 128x128 grayscale X-rays."""
    inputs = layers.Input(shape=INPUT_SHAPE, name="xray_input")

    # Encoder
    x = layers.Conv2D(32, 3, activation="relu", padding="same")(inputs)
    x = layers.MaxPooling2D(2, padding="same")(x)
    x = layers.Conv2D(64, 3, activation="relu", padding="same")(x)
    x = layers.MaxPooling2D(2, padding="same")(x)
    x = layers.Conv2D(128, 3, activation="relu", padding="same")(x)
    latent = layers.MaxPooling2D(2, padding="same", name="latent")(x)

    # Decoder
    x = layers.Conv2D(128, 3, activation="relu", padding="same")(latent)
    x = layers.UpSampling2D(2)(x)
    x = layers.Conv2D(64, 3, activation="relu", padding="same")(x)
    x = layers.UpSampling2D(2)(x)
    x = layers.Conv2D(32, 3, activation="relu", padding="same")(x)
    x = layers.UpSampling2D(2)(x)
    outputs = layers.Conv2D(
        1, 3, activation="sigmoid", padding="same", name="reconstruction"
    )(x)

    model = Model(inputs, outputs, name="medical_xray_autoencoder")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="mse",
    )
    return model
